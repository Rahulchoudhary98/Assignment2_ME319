# Guardian predictive turret — ME319 Assignment 2 (Autumn 2026)

Predictive-feedback fire control for the elevation axis of the Guardian laser turret
(Mumbai 2044 scenario): a constant-acceleration Kalman filter estimates the V-44
target from 20 Hz polar radar data, a kinematic predictor generates the elevation
reference over the prescribed horizon `t_p = 0.5 s` (used as a commit-and-fire
scheduling horizon), and a lead–notch LTI compensator `Gc(s)` drives the
first-principles elevation-drive model `Gp(s)`.

## Required interface files

| File | Signature |
|---|---|
| `target_motion_generator.m` | `[r_meas, theta_meas, meas_valid] = target_motion_generator(t, scenario)` (optional 4th output `truth`) |
| `turret_controller.m` | `[V_m, fire_cmd] = turret_controller(t, r_meas, theta_meas, meas_valid, theta_turret, theta_dot_turret)` (optional 3rd output `info`) |
| `turret_plant.m` | `[theta_dot_turret, theta_ddot_turret, i_dot] = turret_plant(t, V_m, theta_turret, theta_dot_turret, i)` |

All physical and design parameters are in `guardian_params.m` (single source of
truth). The compensator coefficients are computed there from the analytical
design procedure, so the design is fixed once and never retuned per scenario.

## Reproducing the results (MATLAB R2019b+ or GNU Octave 8.x)

```matlab
design_controller     % plant, Gc(s), margins, poles, settling, robustness -> results/design_summary.txt
run_scenarios         % scenarios A, B, C (0..10 s)                        -> results/metrics_scenarios.txt, log_*.csv
robustness_tests      % call interval, meas_valid convention, theta0, plant mismatch -> results/robustness.txt
run_monte_carlo       % 40 unseen randomized engagements R101..R140        -> results/mc_summary.txt, mc_*.csv
crossover_study       % redesign at w_c = 8, 15, 25 rad/s (crossover table)  -> results/crossover_study.txt
```

`design_controller.m` needs the Control System Toolbox (MATLAB) or the `control`
package (Octave: `pkg install -forge control`). All other scripts use base
MATLAB/Octave only. Publication figures are drawn from the CSV results with

```bash
python3 make_figures.py   # matplotlib; writes paper/figs/*.pdf
cd paper && pdflatex paper && pdflatex paper
```

The process-noise study (process-noise table of the paper) is reproduced by
`mc_worker(q, 1:30, 'results/tuning/q<q>.csv')` for `q = 100, 400, 1600`.
The randomized-case rows of the crossover table need `do_mc = true` in
`crossover_study.m` (about 10 minutes per crossover value).

## Using the controller with the instructor's evaluation script

`turret_controller` keeps its state in persistent variables and restarts
automatically when it is called with `t = 0` (or when time runs backwards by more
than 0.5 s). Call `clear turret_controller` between evaluation cases to be safe.
The controller

* integrates its filters on elapsed time, so any call interval works (tested at 1–5 ms);
* accepts a radar sample at most once per ~50 ms, so it works whether
  `meas_valid` is raised only on the sample instant or on every call;
* treats `meas_valid = 0` (or `NaN` data) as measurement loss (prediction only);
* issues `fire_cmd = 1` for a single call per pulse and never re-arms before the
  1.0 s recharge has elapsed.

## Repository layout

```
guardian_params.m            parameters + analytical compensator design
turret_plant.m               elevation drive (armature + gear + trunnion, end stops)
turret_controller.m          KF estimator, predictor, scheduler, Gc(s), fire logic
target_motion_generator.m    scenarios A/B/C and randomized cases R<n>, radar model
simulate_engagement.m        closed-loop simulation and pulse scoring
engagement_metrics.m         performance measures
design_controller.m          frequency-domain design verification
run_scenarios.m, run_monte_carlo.m, robustness_tests.m, crossover_study.m, mc_worker.m, plant_perturbed.m
make_figures.py              figures for the paper
design/                      Python design-exploration scripts (notch width / crossover search)
results/                     generated results (CSV, TXT)
paper/                       IEEE paper source (LaTeX) and figures
```

## Scenario definitions

* **A** – straight 145 m/s crossing pass from (1500, 250) m, velocity (−100, 105) m/s.
* **B** – same entry; from t = 1 s a weaving turn with normal acceleration
  18 sin(2π(t−1)/3) m/s² (C¹ blend over 0.5 s): bounded maneuver in x and y.
* **C** – motion of B with radar loss for 1.00 ≤ t < 1.50 s.
* **R<n>** – randomized admissible engagements (seeded, portable PRNG) with
  random geometry, speed 80–150 m/s, two-tone normal and tangential maneuvers
  (|a| ≤ 19.5 m/s²), random onset/blend, and radar loss of 0.2–0.5 s starting
  between 1 and 3 s. Every trajectory is rejected unless
  800 ≤ r ≤ 2000 m, |v| ≤ 150 m/s and |a| ≤ 20 m/s² hold throughout.
