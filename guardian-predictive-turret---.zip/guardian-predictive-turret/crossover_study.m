%CROSSOVER_STUDY  Sensitivity of the design to the gain-crossover frequency w_c.
%   Repeats the analytical lead-notch design (guardian_params.m) for
%   w_c = 8, 15 (final design) and 25 rad/s with everything else unchanged,
%   and reports margins, worst-case margins under parameter error, settling
%   time and the closed-loop engagement results. Writes
%   results/crossover_study.txt (crossover table of the paper).
%   Set do_mc = true to add the 40 randomized cases R101..R140 (slow).
%   Requires the Control System Toolbox (MATLAB) or the 'control' package (Octave).
clear all; clc;
do_mc = false;
if exist('OCTAVE_VERSION', 'builtin'), pkg load control; end
global WC_OVERRIDE
if ~exist('results', 'dir'), mkdir('results'); end
wc_list = [8 15 25];
fid = fopen('results/crossover_study.txt', 'w');
pr = @(varargin) cellfun(@(f) fprintf(f, varargin{:}), {1, fid});
for k = 1:numel(wc_list)
    WC_OVERRIDE = wc_list(k);
    clear guardian_params turret_controller turret_plant   % drop cached parameters and states
    P  = guardian_params();
    Gp = tf(P.Gp_num, P.Gp_den);  Gc = tf(P.Gc_num, P.Gc_den);
    [gm, pm, wpc] = margin(Gc*Gp);
    gmw = inf;                                              % worst-case GM, same grid as design_controller.m
    for dJ = [0.8 1.2], for dL = [0.8 1.2], for db = [0.7 1.3]
        Jq = P.J_turret*dJ + P.N^2*P.J_m;
        Gq = tf(P.N*P.K_t, [P.L_m*dL*Jq, P.L_m*dL*P.b*db + P.R_m*Jq, P.R_m*P.b*db + P.N^2*P.K_t*P.K_e, 0]);
        gmw = min(gmw, margin(Gc*Gq));
    end, end, end
    [y, tt] = step(minreal(feedback(Gc*Gp, 1), 1e-5), 0:1e-4:2); y = y(:);
    ts = tt(find(abs(y - 1) > 1e-3, 1, 'last') + 1);
    pr('w_c = %g rad/s: phi_lead = %.2f deg, K = %.0f V/rad, Kv = %.2f 1/s\n', P.w_c, P.phi_lead, P.K, P.K*P.Gp_num/P.Gp_den(3));
    pr('  GM = %.2f dB at %.1f rad/s, PM = %.2f deg, worst-case GM = %.2f dB, 0.1%% settling = %.3f s\n', ...
       20*log10(gm), wpc, pm, 20*log10(gmw), ts);
    sc = {'A', 'B', 'C'};
    for i = 1:3
        [L, M] = simulate_engagement(sc{i});
        e = zeros(size(L.pulses, 1), 1);                    % turret-minus-reference offset at each pulse [m]
        for j = 1:numel(e)
            [~, n] = min(abs(L.t - L.pulses(j, 1)));
            e(j) = abs(L.theta(n) - L.theta_ref(n))*L.r_true(n);
        end
        pr('  %s: t_int %.3f s, hits %d/%d, miss mean %.2f max %.2f m, turret offset at fire mean %.2f max %.2f m, track rms %.1f mrad, Vpk %.0f V, Ipk %.1f A, Vpk(t>1) %.0f V\n', ...
           sc{i}, M.t_intercept, M.n_hits, M.n_pulses, M.miss_mean, M.miss_max, mean(e), max(e), ...
           1e3*M.track_err_rms, M.V_peak, M.I_peak, M.V_peak_after1s);
    end
    pf = @(t, V, a, b, c) plant_perturbed(t, V, a, b, c, 1.2, 1.2, 1.0);   % worst-case plant: J_turret, L_m +20 %
    [L, M] = simulate_engagement('C', struct('plant_fun', pf));
    pr('  C with J x1.2, L x1.2: hits %d/%d, miss mean %.2f max %.2f m, Vpk(t>1) %.0f V, rms V(t>1) %.0f V\n', ...
       M.n_hits, M.n_pulses, M.miss_mean, M.miss_max, M.V_peak_after1s, sqrt(mean(L.V(L.t > 1).^2)));
    if do_mc
        nh = 0; np_ = 0; ns = 0; ti = []; ms = [];
        for c = 101:140
            [L, M] = simulate_engagement(sprintf('R%d', c));
            nh = nh + M.n_hits; np_ = np_ + M.n_pulses; ns = ns + M.success; ti(end+1) = M.t_intercept; %#ok<SAGROW>
            if ~isempty(L.pulses), ms = [ms; L.pulses(:, 2)]; end %#ok<AGROW>
        end
        pr('  R101-R140: success %d/40, hits %d/%d, miss mean %.2f m, 95th pct %.2f m, t_int mean %.2f s\n', ...
           ns, nh, np_, mean(ms), prctile_(ms, 95), mean(ti(isfinite(ti))));
    end
end
fclose(fid);
WC_OVERRIDE = [];
clear guardian_params turret_controller turret_plant       % restore the final design (w_c = 15)
