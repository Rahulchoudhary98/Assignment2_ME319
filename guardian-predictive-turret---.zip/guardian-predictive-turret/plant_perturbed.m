function [th_d, th_dd, i_dot] = plant_perturbed(t, V, th, th_d, i, sJ, sL, sb)
%PLANT_PERTURBED  Elevation drive with scaled J_turret, L_m and b (robustness tests only).
P = guardian_params();
Jeq = sJ*P.J_turret + P.N^2*P.J_m;
i_dot = (V - P.R_m*i - P.K_e*P.N*th_d)/(sL*P.L_m);
th_dd = (P.N*P.K_t*i - sb*P.b*th_d)/Jeq;
end
