function M = engagement_metrics(L, P)
%ENGAGEMENT_METRICS  Quantitative performance measures of one simulated engagement.
pul = L.pulses;
M.n_pulses = size(pul, 1);
M.n_hits   = sum(pul(:,3));
M.success  = M.n_hits > 0;
if M.success, M.t_intercept = pul(find(pul(:,3), 1), 1); else, M.t_intercept = NaN; end
if M.n_pulses > 0
    M.miss_mean = mean(pul(:,2)); M.miss_max = max(pul(:,2)); M.miss_all = pul(:,2)';
else
    M.miss_mean = NaN; M.miss_max = NaN; M.miss_all = [];
end
M.hit_ratio = M.n_hits/max(M.n_pulses, 1);
ok = ~isnan(L.xhat) & L.t >= 0.5;                     % after filter start-up
ep = hypot(L.xhat - L.x, L.yhat - L.y);
M.pos_err_rms = sqrt(mean(ep(ok).^2));
ev = hypot(L.vxhat - L.vx, L.vyhat - L.vy);
M.vel_err_rms = sqrt(mean(ev(ok).^2));
% cross-range (LOS-normal) estimation error, the component that matters for aiming
M.cross_err_rms = sqrt(mean(((L.theta_hat(ok) - L.theta_true(ok)).*L.r_true(ok)).^2));
% fixed-horizon (t_p) prediction error: predicted at t vs truth at t + t_p
k_tp = round(P.t_p/(L.t(2) - L.t(1)));
idx = find(ok); idx = idx(idx + k_tp <= numel(L.t));
epred = hypot(L.xp(idx) - L.x(idx + k_tp), L.yp(idx) - L.y(idx + k_tp));
M.pred_err_rms = sqrt(mean(epred.^2)); M.pred_err_max = max(epred);
M.pred_err_t = L.t(idx); M.pred_err = epred;
% turret tracking of its own (conditioned) reference, after acquisition (t >= 1 s)
tr = L.t >= 1.0;
M.track_err_rms = sqrt(mean((L.theta_ref(tr) - L.theta(tr)).^2));
M.V_peak = max(abs(L.V)); M.I_peak = max(abs(L.i));
M.V_peak_after1s = max(abs(L.V(tr))); M.I_peak_after1s = max(abs(L.i(tr)));
M.theta_range = [min(L.theta), max(L.theta)];
end
