function P = guardian_params()
%GUARDIAN_PARAMS  Single source of truth for all physical and design parameters.
%   P = guardian_params() returns a struct with
%     * the physical parameters prescribed in Section 2 of the assignment,
%     * the derived elevation-drive model coefficients, and
%     * every additional design parameter of the estimator, predictor,
%       reference scheduler, feedback compensator Gc(s) and fire logic.
%   The compensator coefficients are computed here from the analytical
%   design procedure (notch + lead, Bode crossover/phase-margin method) so
%   that the controller is designed exactly once and is never retuned per
%   scenario. design_controller.m reproduces and plots the same design.

persistent Pc
global Q_OVERRIDE WC_OVERRIDE       % used only by parameter-study scripts
if ~isempty(Pc) && (isempty(Q_OVERRIDE) || Pc.q_jerk == Q_OVERRIDE) ...
        && (isempty(WC_OVERRIDE) || Pc.w_c == WC_OVERRIDE), P = Pc; return; end

%% ---------------- Physical parameters (Section 2) -----------------------
P.J_turret = 1200;        % turret + cradle inertia about trunnion [kg m^2]
P.J_m      = 0.20;        % motor rotor inertia [kg m^2]
P.N        = 100;         % gear ratio (motor speed = N * turret speed)
P.b        = 1500;        % turret-side viscous damping [N m s/rad]
P.K_t      = 10;          % motor torque constant [N m/A]
P.K_e      = 10;          % back-emf constant [V s/rad]
P.R_m      = 1.0;         % armature resistance [Ohm]
P.L_m      = 0.10;        % armature inductance [H]
P.theta_min = -10*pi/180; % mechanical elevation limits [rad]
P.theta_max =  85*pi/180;

P.Ts_radar  = 0.05;       % radar sample interval [s] (20 Hz)
P.sigma_r   = 1.0;        % range noise std [m]
P.sigma_th  = 0.02*pi/180;% elevation noise std [rad]
P.t_p       = 0.50;       % prescribed prediction horizon [s]
P.t_recharge= 1.0;        % minimum inter-pulse interval [s]
P.R_eng     = 2.0;        % engagement radius [m]
P.v_max     = 150;        % target speed bound [m/s]
P.a_max     = 20;         % target acceleration bound [m/s^2]
P.t_end     = 10;         % standardized engagement duration [s]

%% ---------------- Derived elevation-drive model --------------------------
% Reflected inertia: J_eq = J_turret + N^2 J_m (motor turns N times faster).
P.J_eq = P.J_turret + P.N^2*P.J_m;                 % 3200 kg m^2
% theta(s)/V(s) = N K_t / ( s [ (L s + R)(J_eq s + b) + N^2 K_t K_e ] )
P.Gp_num = P.N*P.K_t;                               % 1000
P.Gp_den = [P.L_m*P.J_eq, P.L_m*P.b + P.R_m*P.J_eq, P.R_m*P.b + P.N^2*P.K_t*P.K_e, 0];
% Lightly damped electromechanical mode (s^2 + 2 zeta_p w_p s + w_p^2)
P.w_p    = sqrt(P.Gp_den(3)/P.Gp_den(1));          % 55.94 rad/s
P.zeta_p = P.Gp_den(2)/P.Gp_den(1)/(2*P.w_p);       % 0.0936

%% ---------------- Feedback compensator Gc(s) -----------------------------
% Gc(s) = K * (1 + T_D s)/(1 + alpha T_D s) * (s^2+2 zeta_p w_p s+w_p^2)/(s^2+2 zeta_d w_p s+w_p^2)
P.zeta_d = 1.5;      % damping of notch poles (widens notch for +-20% robustness)
P.w_c    = 15;       % design gain-crossover frequency [rad/s]
if ~isempty(WC_OVERRIDE), P.w_c = WC_OVERRIDE; end   % crossover_study.m only
P.PM_des = 60;       % design phase margin [deg]
Gp   = @(s) P.Gp_num ./ polyval(P.Gp_den, s);
Nf   = @(s) (s.^2 + 2*P.zeta_p*P.w_p*s + P.w_p^2) ./ (s.^2 + 2*P.zeta_d*P.w_p*s + P.w_p^2);
jw   = 1i*P.w_c;
PM0  = 180 + angle(Nf(jw)*Gp(jw))*180/pi;            % PM of notch-compensated plant
phi  = P.PM_des - PM0;                               % phase lead required [deg]
P.alpha = (1 - sind(phi))/(1 + sind(phi));
P.T_D   = 1/(P.w_c*sqrt(P.alpha));                   % w_max placed at w_c
D    = @(s) (1 + P.T_D*s)./(1 + P.alpha*P.T_D*s);
P.K  = 1/abs(D(jw)*Nf(jw)*Gp(jw));                    % |L(j w_c)| = 1
P.PM0 = PM0; P.phi_lead = phi;
% Transfer-function coefficients of Gc(s)
P.Gc_num = P.K*conv([P.T_D 1], [1 2*P.zeta_p*P.w_p P.w_p^2]);
P.Gc_den = conv([P.alpha*P.T_D 1], [1 2*P.zeta_d*P.w_p P.w_p^2]);
P.Gc_num = P.Gc_num / P.Gc_den(1);  P.Gc_den = P.Gc_den / P.Gc_den(1);
% Controllable canonical state-space realization (biproper: D ~= 0)
a = P.Gc_den(2:end); b = P.Gc_num; n = numel(a);
P.Gc_D = b(1);
c = b(2:end) - b(1)*a;                               % strictly proper remainder
P.Gc_A = [zeros(n-1,1) eye(n-1); -fliplr(a)];
P.Gc_B = [zeros(n-1,1); 1];
P.Gc_C = fliplr(c);

%% ---------------- Target-state estimator (Kalman filter) -----------------
% Constant-acceleration (white-jerk) model per Cartesian axis.
P.q_jerk    = 400;    % white-jerk power spectral density [m^2/s^5]
if ~isempty(Q_OVERRIDE), P.q_jerk = Q_OVERRIDE; end
P.P0_vel    = 150^2;  % initial velocity variance [m^2/s^2]
P.P0_acc    = 20^2;   % initial acceleration variance [m^2/s^4]
P.gate_chi2 = 25;     % innovation gate (chi-square, 2 dof) for outlier rejection
P.n_min_meas = 6;     % measurements before an engagement may be scheduled

%% ---------------- Reference scheduler and fire logic ----------------------
P.ref_rate_max  = 0.8;    % reference slew-rate limit during acquisition [rad/s]
P.ref_margin    = 0.5*pi/180;  % keep reference 0.5 deg inside hard stops
P.e_ready       = 0.05;   % max |theta_ref - theta| to commit an aim point [rad]
P.sigma_ready   = 5.0;    % max predicted cross-range std at the epoch [m]
P.k_gate        = 2.0;    % fire if miss_est + k_gate*sigma_perp <= R_eng
P.w_fire        = 0.06;   % half-width of fire window around the epoch [s]
P.miss_aligned  = 0.25;   % fire immediately if already aligned within this [m]
P.V_max         = 2000;   % drive-voltage clamp (safety; not reached in nominal runs) [V]

Pc = P;
end
