function mc_worker(q, cases, outfile, dt, theta0)
% Helper for parameter studies: runs random cases with a given q_jerk.
if nargin < 4, dt = 1e-3; end
if nargin < 5, theta0 = 0; end
addpath(pwd);
global Q_OVERRIDE; Q_OVERRIDE = q;
R = zeros(numel(cases), 9);
for i = 1:numel(cases)
  [L, M] = simulate_engagement(sprintf('R%d', cases(i)), struct('dt', dt, 'theta0', theta0));
  R(i,:) = [cases(i), M.success, M.t_intercept, M.n_pulses, M.n_hits, M.miss_mean, M.pred_err_rms, M.cross_err_rms, M.V_peak];
  fprintf('%d ', cases(i)); fflush(stdout);
end
dlmwrite(outfile, R);
end
