import control as ct, numpy as np, json
exec(open(__file__.replace('final_design_check.py','notch_crossover_search.py')).read().split("res=[]")[0])
zz,zd,wc=zp,1.5,15
Nn=(s**2+2*zz*wp*s+wp**2)/(s**2+2*zd*wp*s+wp**2); G1=Nn*Gp
PM0=180+np.degrees(np.angle(ct.evalfr(G1,1j*wc))); phi=60-PM0
a=(1-np.sin(np.radians(phi)))/(1+np.sin(np.radians(phi))); Td=1/(wc*np.sqrt(a))
D=(1+Td*s)/(1+a*Td*s); K=1/abs(ct.evalfr(D*G1,1j*wc)); C=K*D*Nn
print("PM0",PM0,"phi",phi,"alpha",a,"Td",Td,"zero",1/Td,"pole",1/(a*Td),"K",K)
print("notch den roots",np.roots([1,2*zd*wp,wp**2]))
L=C*Gp; gm,pm,wpc,wgc=ct.margin(L); print("GM dB",20*np.log10(gm),"wpc",wpc,"PM",pm,"wgc",wgc,"Kv",K*1000/1001500)
T=ct.minreal(ct.feedback(L,1),1e-6,verbose=False); print("T poles",np.round(T.poles(),3),"zeros",np.round(T.zeros(),3))
print("closed-loop all poles", np.round(ct.feedback(L,1).poles(),3))
i=ct.step_info(T,SettlingTimeThreshold=0.02); print({k:round(v,4) for k,v in i.items()})
t=np.linspace(0,2,20001); y=ct.step_response(T,t).outputs
for thr in [0.02,0.01,0.001]:
    idx=np.where(np.abs(y-1)>thr)[0]; print("settle",thr,t[idx[-1]+1])
print("BW",ct.bandwidth(T)); w=np.logspace(-1,3,5000)
print("Mpeak dB",20*np.log10(max(abs(ct.frequency_response(T,w).fresp[0,0]))))
S=ct.feedback(1,L); print("Ms",max(abs(ct.frequency_response(S,w).fresp[0,0])))
U=ct.feedback(C,Gp); print("|C| HF",abs(ct.evalfr(C,1e4j)),"DC K",K, "U/R step peak per rad", ct.step_info(U)['Peak'] if False else None)
print("ramp error coefficient 1/Kv",1/(K*1000/1001500))
# delay margin
print("delay margin s", np.radians(pm)/wgc)
# discrete check: ZOH 1ms phase loss
print("ZOH phase loss at wgc (1ms)", np.degrees(wgc*0.001/2))
num=np.array(ct.minreal(C,verbose=False).num[0][0]); den=np.array(ct.minreal(C,verbose=False).den[0][0])
json.dump(dict(K=K,alpha=a,Td=Td,zp=zp,wp=wp,zd=zd,num=list(num),den=list(den),GM=20*np.log10(gm),PM=pm,wgc=wgc,wpc=wpc),open('design.json','w'),indent=1)
print(num,den)
