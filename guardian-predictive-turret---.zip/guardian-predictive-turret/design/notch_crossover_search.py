import control as ct, numpy as np, itertools
s=ct.tf('s')
def plant(dJ=1,dL=1,db=1,dK=1): return 1000*dK/(s*((0.1*dL*s+1)*((1200*dJ+2000)*s+1500*db)+1e6*dK*dK))
Gp=plant(); wp=np.sqrt(1001500/320); zp=3350/320/(2*wp)
def design(zz,zd,wc,PMdes):
    Nn=(s**2+2*zz*wp*s+wp**2)/(s**2+2*zd*wp*s+wp**2)
    G1=Nn*Gp; PM0=180+np.degrees(np.angle(ct.evalfr(G1,1j*wc))); phi=PMdes-PM0
    if phi>0:
        a=(1-np.sin(np.radians(phi)))/(1+np.sin(np.radians(phi))); Td=1/(wc*np.sqrt(a)); D=(1+Td*s)/(1+a*Td*s)
    else: a,Td,D=1,0,1+0*s
    K=1/abs(ct.evalfr(D*G1,1j*wc)); return K*D*Nn,(a,Td,K)
res=[]
t=np.linspace(0,1.0,5001)
for zz,zd,wc in itertools.product([zp,0.15,0.25,0.35],[1.0,1.5,2.0],[15,20,25]):
    C,par=design(zz,zd,wc,60)
    L=C*Gp; gm,pm,_,_=ct.margin(L); T=ct.feedback(L,1)
    if max(T.poles().real)>=0: continue
    r_=np.where(t<0.5,0.375*t,0.1875); y=ct.forced_response(T,t,r_).outputs; e=np.abs(r_-y)
    e_end=e[-1]; e_aim=np.max(e[t>=0.95])  # residual at end of 0.5 s aim phase
    worst=99
    for dJ,dL in itertools.product([0.8,1.2],[0.8,1.2]):
        g2,p2,_,_=ct.margin(C*plant(dJ,dL)); pp=ct.feedback(C*plant(dJ,dL),1).poles()
        worst=min(worst,20*np.log10(g2) if max(pp.real)<0 else -99)
    res.append((zz,zd,wc,20*np.log10(gm),pm,e[2500],e_aim*1e3,worst))
for r in sorted(res,key=lambda r:-r[7]):
    if r[6]<0.2: print("zz=%.3f zd=%.1f wc=%d GM=%.1f PM=%.0f lag@0.5=%.4f resid(mrad)=%.4f worstGM=%.1f"%r)
