import control as ct, numpy as np
s=ct.tf('s')
J=1200; Jm=0.2; N=100; b=1500; Kt=10; Ke=10; R=1.0; L=0.1
Jeq=J+N**2*Jm
Gp=N*Kt/(s*((L*s+R)*(Jeq*s+b)+N**2*Kt*Ke))
print("Jeq",Jeq); print(Gp)
den=np.array([L*Jeq, L*b+R*Jeq, R*b+N**2*Kt*Ke])
print("den",den, "poles",np.roots(den))
wn=np.sqrt(den[2]/den[0]); z=den[1]/den[0]/(2*wn); print("wn",wn,"zeta",z)
print("DC rate gain",N*Kt/den[2], "1/(N Ke)",1/(N*Ke))
print("electrical tau",L/R,"mech tau Jeq/b",Jeq/b)
gm,pm,wpc,wgc=ct.margin(Gp); print("P=1 margins", gm, pm, wpc, wgc)
print("max P gain for GM 6dB:", gm/2)
