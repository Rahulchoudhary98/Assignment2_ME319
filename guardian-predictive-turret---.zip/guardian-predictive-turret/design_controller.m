%DESIGN_CONTROLLER  Analytical design and verification of Gc(s) (Bode / margins).
%   Reproduces the numbers in Section IV of the paper and writes
%   results/design_summary.txt plus CSV data for the design figures.
%   Requires the Control System Toolbox (MATLAB) or the 'control' package (Octave).

clear; clc;
if exist('OCTAVE_VERSION', 'builtin'), pkg load control; end
P = guardian_params();
if ~exist('results', 'dir'), mkdir('results'); end
s  = tf('s');
Gp = tf(P.Gp_num, P.Gp_den);                         % turret elevation plant
Nf = (s^2 + 2*P.zeta_p*P.w_p*s + P.w_p^2)/(s^2 + 2*P.zeta_d*P.w_p*s + P.w_p^2);
Dl = (1 + P.T_D*s)/(1 + P.alpha*P.T_D*s);
Gc = P.K*Dl*Nf;
L  = Gc*Gp;  T = feedback(L, 1);  S = feedback(1, L);  U = feedback(Gc, Gp);

fid = fopen('results/design_summary.txt', 'w');
pr = @(varargin) cellfun(@(f) fprintf(f, varargin{:}), {1, fid});
pr('Plant: theta/V = %.0f / (%.0f s^3 + %.0f s^2 + %.0f s)\n', P.Gp_num, P.Gp_den(1:3));
pr('J_eq = %.0f kg m^2, w_p = %.3f rad/s, zeta_p = %.4f\n', P.J_eq, P.w_p, P.zeta_p);
pr('Plant poles: %s\n', mat2str(roots(P.Gp_den).', 5));
[gm0, pm0, wpc0, wgc0] = margin(Gp);
pr('Max proportional gain for 6 dB GM: K = %.0f V/rad (crossover %.2f rad/s)\n', gm0/2, gm0/2*P.Gp_num/P.Gp_den(3));
pr('Notch-compensated plant PM at w_c=%g: %.2f deg -> lead phi = %.2f deg\n', P.w_c, P.PM0, P.phi_lead);
pr('Lead: alpha = %.4f, T_D = %.5f s, zero %.3f rad/s, pole %.3f rad/s\n', P.alpha, P.T_D, 1/P.T_D, 1/(P.alpha*P.T_D));
pr('K = %.1f V/rad, Kv = %.2f 1/s\n', P.K, P.K*P.Gp_num/P.Gp_den(3));
pr('Gc num: %s\nGc den: %s\n', mat2str(P.Gc_num, 6), mat2str(P.Gc_den, 6));
[gm, pm, wpc, wgc] = margin(L);
pr('Margins: GM = %.2f dB at %.2f rad/s, PM = %.2f deg at %.2f rad/s\n', 20*log10(gm), wpc, pm, wgc);
pr('Delay margin = %.4f s\n', pm*pi/180/wgc);
p = pole(T); pr('Closed-loop poles: %s\n', mat2str(p.', 5));
Tm = minreal(T, 1e-5);
pr('Reference-to-output poles: %s, zeros: %s\n', mat2str(pole(Tm).', 5), mat2str(zero(Tm).', 5));
[y, tt] = step(Tm, 0:1e-4:1.5); y = y(:); tt = tt(:);
for thr = [0.02 0.01 0.001]
    idx = find(abs(y - 1) > thr, 1, 'last'); pr('Settling to %.1f%%: %.3f s\n', 100*thr, tt(idx+1));
end
pr('Overshoot: %.2f %%, peak time %.3f s\n', 100*(max(y) - 1), tt(find(y == max(y), 1)));
w = logspace(-1, 3, 4000);
magT = squeeze(abs(freqresp(Tm, w))); magS = squeeze(abs(freqresp(S, w)));
pr('Closed-loop bandwidth (-3 dB) = %.2f rad/s, Mpeak = %.2f dB, Ms = %.3f\n', ...
   w(find(magT < 1/sqrt(2), 1)), 20*log10(max(magT)), max(magS));
pr('Ramp (velocity) error constant: e_ss/omega = 1/Kv = %.4f s\n', 1/(P.K*P.Gp_num/P.Gp_den(3)));
% robustness to parameter uncertainty (inertia and inductance +-20 %, damping +-30 %)
pr('Robustness (J_turret, L_m, b scale) -> GM [dB], PM [deg], max Re(p):\n');
for dJ = [0.8 1.2], for dL = [0.8 1.2], for db = [0.7 1.3]
    Jq = P.J_turret*dJ + P.N^2*P.J_m;
    Gq = tf(P.N*P.K_t, [P.L_m*dL*Jq, P.L_m*dL*P.b*db + P.R_m*Jq, P.R_m*P.b*db + P.N^2*P.K_t*P.K_e, 0]);
    [g2, p2] = margin(Gc*Gq); pp = pole(feedback(Gc*Gq, 1));
    pr('  %.1f %.1f %.1f -> %6.2f %6.2f %7.3f\n', dJ, dL, db, 20*log10(g2), p2, max(real(pp)));
end, end, end
fclose(fid);

% ---- data for the design figures ----
w = logspace(-1, 3, 800);
H = [squeeze(freqresp(Gp, w)), squeeze(freqresp(Nf*Gp, w)), squeeze(freqresp(L, w)), squeeze(freqresp(Tm, w))];
csvwrite('results/design_bode.csv', [w(:), 20*log10(abs(H)), unwrap(angle(H))*180/pi]);
[y, tt] = step(Tm, 0:1e-3:1.0); [yv, ~] = step(U, 0:1e-3:1.0);
[yP, ~] = step(feedback(gm0/2*Gp, 1), 0:1e-3:1.0);      % proportional loop with 6 dB GM
csvwrite('results/design_step.csv', [tt(:), y(:), yv(:), yP(:)]);
csvwrite('results/design_poles.csv', [real(p(:)), imag(p(:))]);
disp('Design summary written to results/design_summary.txt');
