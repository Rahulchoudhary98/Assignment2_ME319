function q = prctile_(x, p)
%PRCTILE_  Percentile without toolbox dependence (linear interpolation).
x = sort(x(:)); n = numel(x); if n == 0, q = NaN; return; end
r = 1 + (n - 1)*p/100; lo = floor(r); hi = ceil(r); q = x(lo) + (r - lo)*(x(hi) - x(lo));
end
