function [theta_dot_turret, theta_ddot_turret, i_dot] = turret_plant(t, V_m, theta_turret, theta_dot_turret, i)
%TURRET_PLANT  Elevation-drive dynamics derived from first principles.
%
%   Armature circuit (Kirchhoff):   L_m di/dt = V_m - R_m i - K_e * w_m
%   Gear kinematics (100:1):        w_m = N * theta_dot
%   Torque at the trunnion:         tau = N * K_t * i      (ideal, lossless gear)
%   Rotational dynamics (Newton):   J_eq theta_ddot = N K_t i - b theta_dot + tau_stop
%   with reflected inertia          J_eq = J_turret + N^2 J_m.
%
%   The trunnion is assumed mass-balanced (no gravity torque is specified),
%   the gear is rigid and backlash-free, and the drive is linear. The only
%   nonlinearity is the mechanical end stop at -10 deg / +85 deg, modelled as
%   a stiff spring-damper that acts only when a limit is exceeded. Within
%   the limits the model is exactly the LTI plant Gp(s) used for design:
%       theta(s)/V(s) = N K_t / ( s [ (L s + R)(J_eq s + b) + N^2 K_t K_e ] ).
%
%   Outputs are the state derivatives [theta_dot; theta_ddot; i_dot].

P = guardian_params();

% Mechanical end stops (contact model, inactive inside the limits)
k_stop = 5e6;                       % contact stiffness [N m/rad]
c_stop = 2*0.7*sqrt(k_stop*P.J_eq); % ~critically damped contact [N m s/rad]
tau_stop = 0;
if theta_turret > P.theta_max
    tau_stop = -k_stop*(theta_turret - P.theta_max) - c_stop*max(theta_dot_turret, 0);
elseif theta_turret < P.theta_min
    tau_stop = -k_stop*(theta_turret - P.theta_min) - c_stop*min(theta_dot_turret, 0);
end

i_dot             = (V_m - P.R_m*i - P.K_e*P.N*theta_dot_turret) / P.L_m;
theta_ddot_turret = (P.N*P.K_t*i - P.b*theta_dot_turret + tau_stop) / P.J_eq;
% theta_dot_turret is returned unchanged: d(theta)/dt = theta_dot
end
