function [log, M] = simulate_engagement(scenario, opts)
%SIMULATE_ENGAGEMENT  Closed-loop simulation of one engagement (0 <= t <= t_end).
%   [log, M] = simulate_engagement(scenario, opts)
%   opts.dt       integration / controller step [s]      (default 1e-3)
%   opts.theta0   initial turret elevation [rad]         (default 0)
%   opts.t_end    final time [s]                         (default 10)
%   opts.plant_fun   plant derivative function handle     (default @turret_plant)
%   opts.valid_hold  true -> meas_valid = 1 on every call between radar
%                    samples (tests the alternative interface convention)
%   The plant (turret_plant) is integrated with RK4; the controller output is
%   held constant over each step (zero-order hold). Laser pulses are issued on
%   0->1 transitions of fire_cmd and ignored if the 1.0 s recharge has not
%   elapsed. Each pulse is scored with the exact ray-to-target distance.

if nargin < 2, opts = struct(); end
P = guardian_params();
dt = getopt(opts, 'dt', 1e-3); t_end = getopt(opts, 't_end', P.t_end);
th0 = getopt(opts, 'theta0', 0);
plant_fun = getopt(opts, 'plant_fun', @turret_plant); valid_hold = getopt(opts, 'valid_hold', false);

clear turret_controller target_motion_generator
N = round(t_end/dt) + 1; t = (0:N-1)*dt;
z = [th0; 0; 0];                               % [theta; theta_dot; i]
L = struct('t', t, 'theta', zeros(1,N), 'theta_dot', zeros(1,N), 'i', zeros(1,N), ...
    'V', zeros(1,N), 'fire', zeros(1,N), 'theta_ref', zeros(1,N), 'theta_hat', nan(1,N), ...
    'theta_true', zeros(1,N), 'r_true', zeros(1,N), 'x', zeros(1,N), 'y', zeros(1,N), ...
    'xhat', nan(1,N), 'yhat', nan(1,N), 'vxhat', nan(1,N), 'vyhat', nan(1,N), ...
    'vx', zeros(1,N), 'vy', zeros(1,N), 'xp', nan(1,N), 'yp', nan(1,N), ...
    'sigma', nan(1,N), 'r_meas', nan(1,N), 'theta_meas', nan(1,N), 'valid', zeros(1,N), ...
    'aim', zeros(1,N));
pulses = zeros(0, 4);          % [t, miss distance, hit, LOS angle error]
fire_prev = 0; t_last_pulse = -Inf;

for k = 1:N
    tk = t(k);
    [rm, thm, valid, tr] = target_motion_generator(tk, scenario);
    if valid_hold                                   % sample held, flagged valid every call
        if valid, held = [rm, thm]; end
        if exist('held', 'var') && isfinite(rm), rm = held(1); thm = held(2); valid = true; end
    end
    [V, fire, info] = turret_controller(tk, rm, thm, valid, z(1), z(2));
    % --- pulse bookkeeping (evaluator semantics) ---
    if fire == 1 && fire_prev == 0 && (tk - t_last_pulse) >= P.t_recharge
        d = ray_miss(z(1), tr.x, tr.y);
        pulses(end+1,:) = [tk, d, d <= P.R_eng, z(1) - tr.theta]; %#ok<AGROW>
        t_last_pulse = tk;
    end
    fire_prev = fire;
    % --- log ---
    L.theta(k) = z(1); L.theta_dot(k) = z(2); L.i(k) = z(3); L.V(k) = V; L.fire(k) = fire;
    L.theta_ref(k) = info.theta_ref; L.theta_hat(k) = info.theta_hat; L.sigma(k) = info.sigma_perp;
    L.theta_true(k) = tr.theta; L.r_true(k) = tr.r; L.x(k) = tr.x; L.y(k) = tr.y;
    L.vx(k) = tr.vx; L.vy(k) = tr.vy;
    L.xhat(k) = info.X(1); L.yhat(k) = info.X(4); L.vxhat(k) = info.X(2); L.vyhat(k) = info.X(5);
    L.xp(k) = info.X_pred_tp(1); L.yp(k) = info.X_pred_tp(4);
    L.r_meas(k) = rm; L.theta_meas(k) = thm; L.valid(k) = valid; L.aim(k) = strcmp(info.mode, 'AIM');
    % --- plant integration (RK4, ZOH input) ---
    if k < N
        f = @(zz) plant_rhs(plant_fun, tk, V, zz);
        k1 = f(z); k2 = f(z + dt/2*k1); k3 = f(z + dt/2*k2); k4 = f(z + dt*k3);
        z = z + dt/6*(k1 + 2*k2 + 2*k3 + k4);
    end
end
L.pulses = pulses; log = L;
M = engagement_metrics(L, P);
end

function dz = plant_rhs(pf, t, V, z)
[a, b, c] = pf(t, V, z(1), z(2), z(3)); dz = [a; b; c];
end

function d = ray_miss(th, x, y)
% Minimum distance from point (x,y) to the ray from the origin at angle th.
u = [cos(th); sin(th)]; p = [x; y]; s = max(u'*p, 0);
d = norm(p - s*u);
end

function v = getopt(o, f, d)
if isfield(o, f), v = o.(f); else, v = d; end
end
