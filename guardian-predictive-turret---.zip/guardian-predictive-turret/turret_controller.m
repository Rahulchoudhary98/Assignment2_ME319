function [V_m, fire_cmd, info] = turret_controller(t, r_meas, theta_meas, meas_valid, theta_turret, theta_dot_turret)
%TURRET_CONTROLLER  Predictive-feedback fire control for the turret elevation axis.
%
%   [V_m, fire_cmd] = turret_controller(t, r_meas, theta_meas, meas_valid, ...
%                                       theta_turret, theta_dot_turret)
%   [..., info] also returns internal signals for logging/plots.
%
%   Architecture (Fig. 2 of the assignment):
%   1) Target-state estimation: 6-state constant-acceleration Kalman filter in
%      Cartesian coordinates, driven by polar radar data converted to (x, y)
%      with the linearised measurement covariance. Measurement loss
%      (meas_valid = 0) => time update only; covariance grows.
%   2) Target prediction: kinematic CA extrapolation x(t+h) = F(h) x(t) with
%      covariance F P F' + Q(h).
%   3) Elevation reference: theta_ref = atan2(y_hat(t+h), x_hat(t+h)), where
%      the horizon h follows the engagement schedule ("commit-and-fire"):
%        TRACK : h = min(t_p, t - t_anchor)  (lead tracking at h = t_p)
%        AIM   : at commit time t_c the epoch T = t_c + t_p is frozen and
%                theta_ref = elevation of the predicted target position at T,
%                refined with every new radar sample (horizon T - t -> 0).
%      The turret therefore reaches the predicted intercept point within the
%      prescribed horizon t_p, and the pulse is fired when the target is
%      estimated to cross the (nearly stationary) beam.
%   4) Feedback: LTI compensator Gc(s) = lead x notch (guardian_params),
%      e = theta_ref - theta_turret, implemented by exact ZOH discretisation
%      for the actual call interval.
%   5) Fire logic: inside |t - T| <= w_fire, fire at the closest approach of
%      the estimated target elevation to the beam, provided
%      miss_est + k_gate*sigma_perp <= R_eng and the recharge time has elapsed.
%
%   Robust to the call pattern: all filters integrate on elapsed time, a radar
%   sample is accepted only if its value changed since the last accepted one
%   (and >= 25 ms later), so a held sample with meas_valid = 1 on every call is
%   not re-used; repeated or backward
%   time stamps do not update the states, and t = 0 restarts the controller.

persistent S
P = guardian_params();
if isempty(S) || (t <= 1e-12 && S.t_prev > 1e-12) || t < S.t_prev - 0.5
    S = init_state(P, t, theta_turret);
end
dt = t - S.t_prev;  if dt < 0, dt = 0; end

%% 1) Estimation ----------------------------------------------------------
new_meas = false;
if meas_valid && isfinite(r_meas) && isfinite(theta_meas) && r_meas > 0
    if ~S.kf_init
        z = r_meas*[cos(theta_meas); sin(theta_meas)];
        R = meas_cov(r_meas, theta_meas, P);
        S.X = [z(1); 0; 0; z(2); 0; 0];
        S.Pk = zeros(6); S.Pk([1 4],[1 4]) = R;
        S.Pk(2,2) = P.P0_vel; S.Pk(5,5) = P.P0_vel;
        S.Pk(3,3) = P.P0_acc; S.Pk(6,6) = P.P0_acc;
        S.t_kf = t; S.t_meas = t; S.kf_init = true; S.n_meas = 1; new_meas = true;
        S.z_last = [r_meas, theta_meas];
    elseif (r_meas ~= S.z_last(1) || theta_meas ~= S.z_last(2)) && t - S.t_meas >= 0.5*P.Ts_radar
        [X, Pk] = kf_predict(S.X, S.Pk, t - S.t_kf, P.q_jerk);
        z = r_meas*[cos(theta_meas); sin(theta_meas)];
        R = meas_cov(r_meas, theta_meas, P);
        H = [1 0 0 0 0 0; 0 0 0 1 0 0];
        nu = z - H*X;  Sv = H*Pk*H' + R;
        if nu'*(Sv\nu) <= P.gate_chi2 || S.n_meas < 3
            Kg = Pk*H'/Sv;
            X = X + Kg*nu;
            Pk = (eye(6) - Kg*H)*Pk*(eye(6) - Kg*H)' + Kg*R*Kg';   % Joseph form
            S.n_meas = S.n_meas + 1;
        end
        X = admissible(X, P);
        S.X = X; S.Pk = Pk; S.t_kf = t; S.t_meas = t; new_meas = true;
        S.z_last = [r_meas, theta_meas];
    end
end

%% 2) Current estimate and prediction --------------------------------------
if S.kf_init
    [Xt, Pt] = kf_predict(S.X, S.Pk, t - S.t_kf, P.q_jerk);
    [th_now, r_now, thd_now, sig_now] = los(Xt, Pt);
else
    th_now = theta_turret; r_now = 1500; thd_now = 0; sig_now = Inf; Xt = nan(6,1);
end

%% 3) Engagement schedule and elevation reference ----------------------------
fire_cmd = 0;
if S.kf_init
    switch S.mode
        case 'TRACK'
            h = min(P.t_p, max(t - S.t_anchor, 0));
            [Xh, Ph] = kf_predict(S.X, S.Pk, t + h - S.t_kf, P.q_jerk);
            [th_ref_raw, ~, ~, sig_h] = los(Xh, Ph);
            can_fire_at_epoch = (t + P.t_p) >= S.t_last_fire + P.t_recharge + 1e-3;
            ready = h >= P.t_p - 1e-9 && S.n_meas >= P.n_min_meas && sig_h <= P.sigma_ready ...
                    && abs(S.th_ref - theta_turret) <= P.e_ready && can_fire_at_epoch ...
                    && th_ref_raw > P.theta_min + P.ref_margin && th_ref_raw < P.theta_max - P.ref_margin;
            if ready
                S.mode = 'AIM'; S.T = t + P.t_p; S.d_prev = NaN;
            end
        case 'AIM'
            [XT, PT] = kf_predict(S.X, S.Pk, S.T - S.t_kf, P.q_jerk);
            th_ref_raw = los(XT, PT);
            % ---- fire decision ----
            if abs(t - S.T) <= P.w_fire && (t - S.t_last_fire) >= P.t_recharge + 1e-3
                d   = wrap(th_now - theta_turret);           % estimated LOS error
                dd  = thd_now - theta_dot_turret;             % relative LOS rate
                dtn = max(S.dt_call, 1e-4);
                miss = r_now*abs(d);
                closest = abs(d + dd*dtn) >= abs(d) || (isfinite(S.d_prev) && sign(d) ~= sign(S.d_prev));
                if (closest || miss <= P.miss_aligned) && (miss + P.k_gate*sig_now <= P.R_eng)
                    fire_cmd = 1; S.t_last_fire = t; S.n_fired = S.n_fired + 1;
                end
                S.d_prev = d;
            end
            if fire_cmd || t > S.T + P.w_fire
                S.mode = 'TRACK'; S.t_anchor = t;   % horizon ramps 0 -> t_p again
            end
    end
else
    th_ref_raw = theta_turret;
end

% reference conditioning: elevation limits and slew-rate limit
th_ref_raw = min(max(th_ref_raw, P.theta_min + P.ref_margin), P.theta_max - P.ref_margin);
step = th_ref_raw - S.th_ref; lim = P.ref_rate_max*dt;
S.th_ref = S.th_ref + min(max(step, -lim), lim);

%% 4) Feedback compensator Gc(s) ------------------------------------------
if dt > 0
    if abs(dt - S.dt_disc) > 1e-12
        [S.Ad, S.Bd] = zoh(P.Gc_A, P.Gc_B, dt); S.dt_disc = dt;
    end
    S.xc = S.Ad*S.xc + S.Bd*S.e_prev;   % advance with the input held since last call
end
e = S.th_ref - theta_turret;
V_m = P.Gc_C*S.xc + P.Gc_D*e;
V_m = min(max(V_m, -P.V_max), P.V_max);
S.e_prev = e;

%% bookkeeping ------------------------------------------------------------
if dt > 0, S.dt_call = dt; end
S.t_prev = t;
if nargout > 2
    info.theta_ref = S.th_ref; info.theta_hat = th_now; info.r_hat = r_now;
    info.theta_dot_hat = thd_now; info.sigma_perp = sig_now; info.X = Xt;
    info.mode = S.mode; info.T = S.T; info.new_meas = new_meas; info.e = e;
    if S.kf_init
        [Xp, ~] = kf_predict(S.X, S.Pk, t + P.t_p - S.t_kf, P.q_jerk);   % fixed-horizon prediction
        info.X_pred_tp = Xp;
    else
        info.X_pred_tp = nan(6,1);
    end
end
end

% =========================================================================
function S = init_state(P, t, theta0)
S.t_prev = t; S.kf_init = false; S.X = zeros(6,1); S.Pk = eye(6); S.t_kf = t;
S.t_meas = -Inf; S.n_meas = 0; S.z_last = [NaN NaN];
S.mode = 'TRACK'; S.t_anchor = -Inf; S.T = NaN; S.t_last_fire = -Inf; S.n_fired = 0;
S.d_prev = NaN; S.dt_call = 1e-3;
S.th_ref = theta0;
n = size(P.Gc_A, 1); S.xc = zeros(n,1); S.e_prev = 0; S.dt_disc = -1;
S.Ad = eye(n); S.Bd = zeros(n,1);
end

function R = meas_cov(r, th, P)
J = [cos(th), -r*sin(th); sin(th), r*cos(th)];
R = J*diag([P.sigma_r^2, P.sigma_th^2])*J';
end

function [X, Pk] = kf_predict(X, Pk, h, q)
% Constant-acceleration model with white jerk of PSD q, per axis.
F1 = [1 h h^2/2; 0 1 h; 0 0 1];
Q1 = q*[h^5/20 h^4/8 h^3/6; h^4/8 h^3/3 h^2/2; h^3/6 h^2/2 h];
Z = zeros(3); F = [F1 Z; Z F1]; Q = [Q1 Z; Z Q1];
X = F*X;
if nargout > 1, Pk = F*Pk*F' + Q; end
end

function X = admissible(X, P)
% Project velocity/acceleration estimates onto the known physical envelope.
v = hypot(X(2), X(5)); if v > P.v_max, X([2 5]) = X([2 5])*P.v_max/v; end
a = hypot(X(3), X(6)); if a > P.a_max, X([3 6]) = X([3 6])*P.a_max/a; end
end

function [th, r, thd, sig] = los(X, Pk)
x = X(1); y = X(4); r = hypot(x, y); th = atan2(y, x);
thd = (x*X(5) - y*X(2))/r^2;
if nargin > 1 && nargout > 3
    n = [-sin(th); cos(th)]; Pp = Pk([1 4],[1 4]);
    sig = sqrt(max(n'*Pp*n, 0));
else
    sig = NaN;
end
end

function a = wrap(a)
a = mod(a + pi, 2*pi) - pi;
end

function [Ad, Bd] = zoh(A, B, dt)
n = size(A,1); M = expm([A B; zeros(1, n+1)]*dt);
Ad = M(1:n, 1:n); Bd = M(1:n, n+1);
end
