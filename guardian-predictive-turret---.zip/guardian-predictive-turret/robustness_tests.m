%ROBUSTNESS_TESTS  Interface and model-mismatch checks of the finalized design
%   (scenario C, the hardest standardized case):
%   call interval 1/2/5 ms, alternative meas_valid convention, initial turret
%   elevation 0/45/80 deg, and plant parameter errors (J_turret, L_m +-20 %).
clear; clc;
if ~exist('results', 'dir'), mkdir('results'); end
T = {};
add = @(name, M) sprintf('%-34s hits %2d/%2d  t_int %6.3f s  mean miss %.2f m  max miss %.2f m', ...
    name, M.n_hits, M.n_pulses, M.t_intercept, M.miss_mean, M.miss_max);
[~, M] = simulate_engagement('C');                                   T{numel(T)+1} = add('nominal (dt = 1 ms)', M);
[~, M] = simulate_engagement('C', struct('dt', 2e-3));               T{numel(T)+1} = add('controller step 2 ms', M);
[~, M] = simulate_engagement('C', struct('dt', 5e-3));               T{numel(T)+1} = add('controller step 5 ms', M);
[~, M] = simulate_engagement('C', struct('valid_hold', true));       T{numel(T)+1} = add('meas_valid held high', M);
[~, M] = simulate_engagement('C', struct('theta0', 45*pi/180));      T{numel(T)+1} = add('theta_T(0) = 45 deg', M);
[~, M] = simulate_engagement('C', struct('theta0', 80*pi/180));      T{numel(T)+1} = add('theta_T(0) = 80 deg', M);
scl = [0.8 0.8; 0.8 1.2; 1.2 0.8; 1.2 1.2];
for k = 1:size(scl, 1)
    sJ = scl(k,1); sL = scl(k,2);
    pf = @(t, V, a, b, c) plant_perturbed(t, V, a, b, c, sJ, sL, 1.0);
    [~, M] = simulate_engagement('C', struct('plant_fun', pf));
    T{numel(T)+1} = add(sprintf('plant J x%.1f, L x%.1f', sJ, sL), M);
end
fid = fopen('results/robustness.txt', 'w');
for k = 1:numel(T), fprintf('%s\n', T{k}); fprintf(fid, '%s\n', T{k}); end
fclose(fid);
