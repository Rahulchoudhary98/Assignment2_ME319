%RUN_SCENARIOS  Simulate standardized scenarios A, B, C (0 <= t <= 10 s) with the
%   single finalized design and export logs, pulse records and metrics to results/.
clear; clc;
if ~exist('results', 'dir'), mkdir('results'); end
scen = {'A', 'B', 'C'};
fid = fopen('results/metrics_scenarios.txt', 'w');
hdr = 'scen success t_int[s] pulses hits miss_mean[m] miss_max[m] pos_rms[m] vel_rms[m/s] cross_rms[m] pred_rms[m] pred_max[m] track_rms[mrad] Vpk[V] Ipk[A] Vpk_t>1[V]';
fprintf('%s\n', hdr); fprintf(fid, '%s\n', hdr);
for i = 1:numel(scen)
    [L, M] = simulate_engagement(scen{i});
    row = [M.success, M.t_intercept, M.n_pulses, M.n_hits, M.miss_mean, M.miss_max, M.pos_err_rms, ...
           M.vel_err_rms, M.cross_err_rms, M.pred_err_rms, M.pred_err_max, 1e3*M.track_err_rms, M.V_peak, M.I_peak, M.V_peak_after1s];
    fmt = ['%s ' repmat('%.4g ', 1, numel(row)) '\n'];
    fprintf(fmt, scen{i}, row); fprintf(fid, fmt, scen{i}, row);
    k = 1:5:numel(L.t);                                   % 5 ms decimation for plots
    D = [L.t(k); L.x(k); L.y(k); L.xhat(k); L.yhat(k); L.xp(k); L.yp(k); L.theta_true(k); ...
         L.theta_hat(k); L.theta_ref(k); L.theta(k); L.V(k); L.i(k); L.sigma(k); L.r_true(k); L.aim(k); ...
         L.vx(k); L.vy(k); L.vxhat(k); L.vyhat(k)]';
    csvwrite(sprintf('results/log_%s.csv', scen{i}), D);
    v = find(L.valid);
    csvwrite(sprintf('results/meas_%s.csv', scen{i}), [L.t(v); L.r_meas(v); L.theta_meas(v)]');
    csvwrite(sprintf('results/pulses_%s.csv', scen{i}), L.pulses);
    csvwrite(sprintf('results/prederr_%s.csv', scen{i}), [M.pred_err_t(1:5:end); M.pred_err(1:5:end)]');
end
fclose(fid);
disp('Logs written to results/log_*.csv; columns: t x y xhat yhat xpred ypred th_true th_hat th_ref th V i sigma r aim vx vy vxhat vyhat');
