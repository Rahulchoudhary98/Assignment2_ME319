#!/usr/bin/env python3
"""Publication figures for the paper, drawn from the CSV files written by the
MATLAB/Octave scripts (design_controller.m, run_scenarios.m, run_monte_carlo.m).
Usage:  python3 make_figures.py      (writes figs/*.pdf)
"""
import os
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

R = "results"
OUT = "figs"
os.makedirs(OUT, exist_ok=True)
plt.rcParams.update({"font.family": "serif", "font.size": 7.5, "axes.labelsize": 7.5,
                     "legend.fontsize": 6.3, "xtick.labelsize": 6.8, "ytick.labelsize": 6.8,
                     "lines.linewidth": 1.0, "axes.grid": True, "grid.alpha": 0.3,
                     "savefig.bbox": "tight", "savefig.pad_inches": 0.02})
C = {"true": "#222222", "ref": "#C0661C", "tur": "#1C5A8A", "est": "#2D7A4C", "hit": "#B0283E",
     "A": "#1C5A8A", "B": "#C0661C", "C": "#2D7A4C"}
W1 = 3.45  # IEEE column width [in]


def load(name):
    return np.loadtxt(os.path.join(R, name), delimiter=",", ndmin=2)


def shade_aim(ax, t, aim, color="#E8EEF5"):
    on = False
    for k in range(len(t)):
        if aim[k] and not on:
            t0, on = t[k], True
        if on and (not aim[k] or k == len(t) - 1):
            ax.axvspan(t0, t[k], color=color, lw=0, zorder=0)
            on = False


def shade_loss(ax, t0=1.0, t1=1.5):
    ax.axvspan(t0, t1, color="#F3D9DD", lw=0, zorder=0)


# ---------------------------------------------------------------- design
def fig_design():
    B = load("design_bode.csv")
    w = B[:, 0]
    mag, ph = B[:, 1:5], B[:, 5:9]
    S = load("design_step.csv")
    fig, ax = plt.subplots(3, 1, figsize=(W1, 4.1), gridspec_kw={"height_ratios": [1.15, 0.85, 1.0]})
    lab = [r"$G_p$", r"$N_f G_p$", r"$L=G_cG_p$", r"$T$ (closed loop)"]
    sty = [dict(color="#888888", ls="--"), dict(color=C["est"], ls=":"), dict(color=C["tur"]), dict(color=C["ref"], lw=0.8)]
    for j in range(4):
        ax[0].semilogx(w, mag[:, j], label=lab[j], **sty[j])
    ax[0].axhline(0, color="k", lw=0.5)
    ax[0].set_ylabel("Magnitude [dB]")
    ax[0].set_ylim(-170, 35)
    ax[0].legend(loc="lower left", ncol=2)
    ax[0].annotate("resonance\n55.9 rad/s, $\\zeta_p$=0.094", xy=(55.9, -80), xytext=(110, -22), fontsize=6,
                   arrowprops=dict(arrowstyle="->", lw=0.5))
    ax[0].annotate(r"$\omega_{gc}$=15 rad/s", xy=(15, 0), xytext=(0.12, 8), fontsize=6, arrowprops=dict(arrowstyle="->", lw=0.5))
    for j in range(3):
        ax[1].semilogx(w, ph[:, j], **sty[j])
    ax[1].axhline(-180, color="k", lw=0.5)
    ax[1].set_ylabel("Phase [deg]")
    ax[1].set_xlabel(r"$\omega$ [rad/s]")
    ax[1].set_ylim(-280, -60)
    ax[1].annotate("PM = 60°", xy=(15, -120), xytext=(1.0, -235), fontsize=6, arrowprops=dict(arrowstyle="->", lw=0.5))
    ax[1].annotate("GM = 20.0 dB\n@ 63.6 rad/s", xy=(63.6, -180), xytext=(170, -140), fontsize=6, arrowprops=dict(arrowstyle="->", lw=0.5))
    t, y = S[:, 0], S[:, 1]
    e = np.abs(1 - y)
    ax2 = ax[2]
    ax2.semilogy(t, np.maximum(e, 1e-6), color=C["tur"], label=r"lead-notch $G_c$: $|1-y(t)|$")
    if S.shape[1] > 3:
        ax2.semilogy(t, np.maximum(np.abs(1 - S[:, 3]), 1e-6), color="#888888", ls="--", label="P only, $K$=5242 (6 dB GM)")
    ax2.axhline(1e-3, color=C["hit"], ls="--", lw=0.7, label="0.1 % (0.1 mrad per 0.1 rad step)")
    ax2.axvline(0.5, color="k", ls=":", lw=0.7)
    ax2.text(0.505, 2e-1, r"$t_p$", fontsize=6.5)
    ax2.set_ylim(1e-6, 2)
    ax2.set_xlim(0, 1.0)
    ax2.set_xlabel("time after aim-point commit [s]")
    ax2.set_ylabel("residual error")
    ax2.legend(loc="lower center", bbox_to_anchor=(0.5, 1.0), ncol=2, fontsize=5.8, frameon=False)
    fig.tight_layout(h_pad=0.4)
    fig.savefig(os.path.join(OUT, "fig_design.pdf"))
    plt.close(fig)


# ------------------------------------------------------------- scenarios
def fig_trajectories():
    fig, ax = plt.subplots(figsize=(W1, 2.6))
    th = np.linspace(-10, 85, 200) * np.pi / 180
    for rr in (800, 2000):
        ax.plot(rr * np.cos(th), rr * np.sin(th), color="#BBBBBB", lw=0.6, ls="--")
    for sc in "ABC":
        L = load(f"log_{sc}.csv")
        Pp = load(f"pulses_{sc}.csv") if os.path.getsize(os.path.join(R, f"pulses_{sc}.csv")) > 0 else np.zeros((0, 4))
        ax.plot(L[:, 1], L[:, 2], color=C[sc], label=f"Scenario {sc}", lw=1.1 if sc != "C" else 0.9,
                ls="-" if sc != "C" else (0, (4, 2)))
        if sc != "A":
            ok = L[:, 0] >= 1.0
        for p in Pp:
            k = np.argmin(np.abs(L[:, 0] - p[0]))
            ax.plot(L[k, 1], L[k, 2], marker="o", ms=2.6, mfc="none", mec=C[sc], mew=0.7)
    M = load("meas_B.csv")
    ax.plot(M[:, 1] * np.cos(M[:, 2]), M[:, 1] * np.sin(M[:, 2]), ".", ms=0.8, color="#999999", label="radar (B)")
    ax.text(270, 1390, "turret at origin (outside view)", fontsize=6)
    ax.text(600, 330, "r = 800 m", fontsize=5.5, color="#888888", rotate=None) if False else None
    ax.set_aspect("equal")
    ax.set_xlabel("x [m]")
    ax.set_ylabel("y [m]")
    ax.set_xlim(250, 1650)
    ax.set_ylim(150, 1450)
    ax.legend(loc="upper right", ncol=1)
    fig.savefig(os.path.join(OUT, "fig_traj.pdf"))
    plt.close(fig)


def fig_tracking(sc="B"):
    L = load(f"log_{sc}.csv")
    Pp = load(f"pulses_{sc}.csv")
    t = L[:, 0]
    fig, ax = plt.subplots(3, 1, figsize=(W1, 3.7), sharex=True, gridspec_kw={"height_ratios": [1.2, 1.0, 0.7]})
    for a in ax:
        shade_aim(a, t, L[:, 15])
        if sc == "C":
            shade_loss(a)
    d = 180 / np.pi
    ax[0].plot(t, L[:, 7] * d, color=C["true"], lw=1.2, label=r"true $\theta$")
    ax[0].plot(t, L[:, 9] * d, color=C["ref"], lw=0.9, label=r"reference $\theta_{\rm ref}$")
    ax[0].plot(t, L[:, 10] * d, color=C["tur"], lw=0.9, ls="--", label=r"turret $\theta_T$")
    for p in Pp:
        k = np.argmin(np.abs(t - p[0]))
        ax[0].plot(p[0], L[k, 10] * d, "v", color=C["hit"] if p[2] else "k", ms=3.2)
    ax[0].set_ylabel("elevation [deg]")
    ax[0].legend(loc="lower right")
    los_err = (L[:, 10] - L[:, 7]) * L[:, 14]          # turret pointing error at target range [m]
    ax[1].plot(t, los_err, color=C["tur"], lw=0.8, label=r"$r(\theta_T-\theta)$")
    ax[1].axhline(2, color=C["hit"], ls="--", lw=0.7)
    ax[1].axhline(-2, color=C["hit"], ls="--", lw=0.7, label=r"$\pm R_{\rm eng}$")
    for p in Pp:
        ax[1].plot(p[0], p[1] * np.sign(np.interp(p[0], t, los_err) + 1e-9), "v", color=C["hit"] if p[2] else "k", ms=3.2)
    ax[1].set_ylim(-60, 60)
    ax[1].set_ylabel("pointing offset [m]")
    ax[1].legend(loc="upper right", ncol=2)
    ax[2].plot(t, L[:, 11], color=C["tur"], lw=0.7)
    ax[2].set_ylabel(r"$V_m$ [V]")
    ax[2].set_xlabel("time [s]")
    ax[2].set_xlim(0, 10)
    fig.tight_layout(h_pad=0.3)
    fig.savefig(os.path.join(OUT, f"fig_track_{sc}.pdf"))
    plt.close(fig)


def fig_estimation():
    fig, ax = plt.subplots(2, 1, figsize=(W1, 2.85), sharex=True)
    L = load("log_C.csv")
    t = L[:, 0]
    shade_loss(ax[0])
    cross = (L[:, 8] - L[:, 7]) * L[:, 14]
    ax[0].plot(t, cross, color=C["est"], lw=0.7, label=r"cross-range error $r(\hat\theta-\theta)$")
    ax[0].fill_between(t, -2 * L[:, 13], 2 * L[:, 13], color=C["est"], alpha=0.18, lw=0, label=r"$\pm 2\sigma_\perp$ (filter)")
    ax[0].set_ylim(-4, 4)
    ax[0].set_ylabel("[m]")
    ax[0].legend(loc="upper right", ncol=1)
    ax[0].text(1.03, -3.5, "radar loss", fontsize=6, color="#A03040")
    shade_loss(ax[1])
    for sc in "ABC":
        E = load(f"prederr_{sc}.csv")
        ax[1].plot(E[:, 0], E[:, 1], color=C[sc], lw=0.8, label=f"Scenario {sc}")
    ax[1].set_ylabel(r"prediction error at $t_p$ [m]")
    ax[1].set_xlabel("prediction time t [s]")
    ax[1].set_xlim(0, 9.5)
    ax[1].set_ylim(0, None)
    ax[1].legend(loc="upper right", ncol=3)
    fig.tight_layout(h_pad=0.3)
    fig.savefig(os.path.join(OUT, "fig_estimation.pdf"))
    plt.close(fig)


def fig_montecarlo():
    f = os.path.join(R, "mc_cases.csv")
    if not os.path.exists(f):
        return
    D = load("mc_cases.csv")
    Pm = load("mc_pulses.csv")
    fig, ax = plt.subplots(1, 2, figsize=(W1, 1.55))
    miss = Pm[:, 2]
    ax[0].hist(np.minimum(miss, 4.0), bins=np.linspace(0, 4, 33), color=C["tur"], alpha=0.85)
    ax[0].axvline(2.0, color=C["hit"], ls="--", lw=0.8)
    ax[0].set_xlabel("miss distance per pulse [m]")
    ax[0].set_ylabel("pulses")
    ti = D[:, 2]
    ti = ti[np.isfinite(ti)]
    ax[1].hist(ti, bins=np.linspace(0, 3, 25), color=C["ref"], alpha=0.85)
    ax[1].set_xlabel("interception time [s]")
    ax[1].set_ylabel("cases")
    fig.tight_layout(w_pad=0.6)
    fig.savefig(os.path.join(OUT, "fig_mc.pdf"))
    plt.close(fig)


if __name__ == "__main__":
    fig_design()
    fig_trajectories()
    fig_tracking("B")
    fig_tracking("C")
    fig_estimation()
    fig_montecarlo()
    print("figures written to", OUT)
