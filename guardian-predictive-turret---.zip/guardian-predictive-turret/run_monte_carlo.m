%RUN_MONTE_CARLO  Generalization study of the finalized design on randomized
%   admissible engagements R101..R140 (disjoint from the tuning set R1..R30):
%   random entry geometry/speed, bounded maneuvers in x and y with random onset,
%   blend time and frequency content, and random radar loss (onset 1-3 s,
%   duration 0.2-0.5 s). Each case also uses a different radar-noise sequence.
clear; clc;
if ~exist('results', 'dir'), mkdir('results'); end
cases = 101:140;
D = nan(numel(cases), 12); Pm = zeros(0, 4);
for i = 1:numel(cases)
    sc = sprintf('R%d', cases(i));
    [L, M] = simulate_engagement(sc);
    D(i,:) = [cases(i), M.success, M.t_intercept, M.n_pulses, M.n_hits, M.miss_mean, M.miss_max, ...
              M.cross_err_rms, M.pred_err_rms, 1e3*M.track_err_rms, M.V_peak, M.I_peak];
    if ~isempty(L.pulses), Pm = [Pm; repmat(cases(i), size(L.pulses,1), 1), L.pulses(:,1:3)]; end %#ok<AGROW>
    fprintf('%s: hit %d/%d, t_int %.3f s, mean miss %.2f m\n', sc, M.n_hits, M.n_pulses, M.t_intercept, M.miss_mean);
end
csvwrite('results/mc_cases.csv', D);    % [case success t_int pulses hits miss_mean miss_max cross_rms pred_rms track_rms Vpk Ipk]
csvwrite('results/mc_pulses.csv', Pm);  % [case t miss hit]
fid = fopen('results/mc_summary.txt', 'w');
s = sprintf(['cases %d | success %d/%d | t_int mean %.3f s, median %.3f, max %.3f | pulses %d, hits %d (%.1f %%) | ' ...
    'miss per pulse mean %.2f m, median %.2f, 95th pct %.2f | cross-range rms %.2f m | pred rms %.2f m | Vpk max %.0f V\n'], ...
    numel(cases), sum(D(:,2)), numel(cases), mean(D(D(:,2)==1,3)), median(D(D(:,2)==1,3)), max(D(:,3)), ...
    size(Pm,1), sum(Pm(:,4)), 100*mean(Pm(:,4)), mean(Pm(:,3)), median(Pm(:,3)), prctile_(Pm(:,3), 95), ...
    mean(D(:,8)), mean(D(:,9)), max(D(:,11)));
fprintf('%s', s); fprintf(fid, '%s', s); fclose(fid);
